import { jest } from '@jest/globals';

// Mocks must be declared before importing modules that use them
jest.mock("./firebase", () => ({
  __esModule: true,
  auth: {},
}));

jest.mock("./services/auth", () => ({
  __esModule: true,
  signOutGoogle: jest.fn(),
}));

// Now import dependencies that rely on the above mocks
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import App from "./App";
import { type User, onAuthStateChanged } from "./firebase";
import { signOutGoogle } from "./services/auth";
import '@testing-library/jest-dom';

describe("App", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("should show loading state initially", () => {
    jest.mocked(onAuthStateChanged).mockImplementationOnce(() => {
      // Do not call callback immediately to simulate loading
      return () => {};
    });
    render(<App />);
    expect(screen.getByText(/Loading.../i)).toBeInTheDocument();
  });

  it("should render AuthPage if no user is logged in", async () => {
    jest.mocked(onAuthStateChanged).mockImplementationOnce((_, nextOrObserver) => {
      if (typeof nextOrObserver === 'function') {
        nextOrObserver(null);
      }
      return () => {};
    });
    render(<App />);
    await waitFor(() => {
      expect(screen.getByRole("heading", { name: /Sign in to your account/i })).toBeInTheDocument();
    });
  });

  it("should render welcome message and logout button if user is logged in", async () => {
    const mockUser = {
      uid: "123",
      email: "test@example.com",
      displayName: "Test User",
    } as User;

    jest.mocked(onAuthStateChanged).mockImplementationOnce((_, nextOrObserver) => {
      if (typeof nextOrObserver === 'function') {
        nextOrObserver(mockUser);
      }
      return () => {};
    });

    render(<App />);

    await waitFor(() => {
      expect(screen.getByText(/Welcome, Test User!/i)).toBeInTheDocument();
      expect(screen.getByRole("button", { name: /Sign Out/i })).toBeInTheDocument();
    });
  });

  it("should call signOutGoogle when logout button is clicked", async () => {
    const mockUser = {
      uid: "123",
      email: "test@example.com",
      displayName: "Test User",
    } as User;

    jest.mocked(onAuthStateChanged).mockImplementationOnce((_, nextOrObserver) => {
      if (typeof nextOrObserver === 'function') {
        nextOrObserver(mockUser);
      }
      return () => {};
    });

    render(<App />);

    await waitFor(() => {
      const logoutButton = screen.getByRole("button", { name: /Sign Out/i });
      fireEvent.click(logoutButton);
      expect(jest.mocked(signOutGoogle)).toHaveBeenCalledTimes(1);
    });
  });
});